﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Caching.Memory;

namespace ScheduleTracker.Pages
{
    public class CreateScheduleModel : PageModel
    {
        [BindProperty]
        public string Time { get; set; }
        [BindProperty]
        public string Action { get; set; }
        [TempData]
        public string Schedule { get; set; }


        private IMemoryCache _cache;
        private string Key = "1";
        public CreateScheduleModel(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
        }

        public void OnGet()
        {

        }

        public ActionResult OnPostAddAction()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            else
            {
                string temp;
                if (!_cache.TryGetValue(Key, out temp))
                {
                    // Key not in cache, so get data.
                    temp = Time + " : " + Action;
                    // Save data in cache.
                    _cache.Set(Key, temp);
                }
                else
                {
                    temp = temp+ System.Environment.NewLine + Time + " : " + Action;
                    _cache.Set(Key, temp);
                }
                Schedule = temp;
                return RedirectToPage();
            }
        }
        public ActionResult OnPostClearSchedule()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            else
            {
                _cache.Remove(Key);
                return RedirectToPage();
            }
        }
    }
}